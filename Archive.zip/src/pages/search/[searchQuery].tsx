export { default, getServerSideProps } from "@/modules/product/search";
// export { default } from "@/modules/product/search";
