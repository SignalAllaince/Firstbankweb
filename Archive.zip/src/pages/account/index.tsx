export { default } from "@/modules/account/profile";
