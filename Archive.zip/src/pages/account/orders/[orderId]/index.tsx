export {
  default,
  getServerSideProps,
} from "@/modules/account/orders/single-order";
