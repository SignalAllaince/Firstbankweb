export { default } from "@/modules/account/orders/open";
