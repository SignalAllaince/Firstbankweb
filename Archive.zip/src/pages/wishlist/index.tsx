export { default } from "@/modules/product/wishlist";
