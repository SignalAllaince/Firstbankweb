export { default } from "@/modules/product/product-page";
