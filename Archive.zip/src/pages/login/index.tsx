export { default } from "@/modules/auth/login/personal";
