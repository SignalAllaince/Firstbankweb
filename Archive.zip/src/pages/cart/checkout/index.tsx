export { default, getServerSideProps } from "@/modules/product/checkout";
