import Favicon from "@/components/favicon";
import Document, { Head, Html, Main, NextScript } from "next/document";

class MyDocument extends Document {
  render() {
    return (
      <Html lang="en">
        <Head>
          <link
            rel="apple-touch-icon"
            href="../../public/favicon/apple-touch-icon.png"
          />
          <link rel="icon" href="../../public/favicon/favicon.ico" />
          <Favicon />
        </Head>
        <body>
          <Main />
          <NextScript />
        </body>
      </Html>
    );
  }
}

export default MyDocument;
