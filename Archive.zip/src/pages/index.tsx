export { default } from "@/modules/product/home";
