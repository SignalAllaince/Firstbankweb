// export {
//   default,
//   getStaticPaths,
//   getStaticProps,
// } from "@/modules/product/category";

export { default, getServerSideProps } from "@/modules/product/category";
