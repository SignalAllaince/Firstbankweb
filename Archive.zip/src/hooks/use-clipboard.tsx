// import { useToast } from "@chakra-ui/react";

// function useClipboard() {
//   const toast = useToast();

//   const copyUrl = (
//     link: string,
//     description = "Payment link copied to clipboard"
//   ) => {
//     navigator.clipboard.writeText(link);

//     toast({
//       title: "Link Copied",
//       description,
//       status: "success",
//       position: "top-right",
//       duration: 3000,
//       variant: "left-accent",
//       isClosable: true,
//     });
//   };

//   return copyUrl;
// }

// export default useClipboard;
